var waveBtn = (function () {
    'use strict';
    var btn = document.querySelectorAll('.wave'),
        tab = document.querySelector('.tab-bar'),
        indicator = document.querySelector('.indicator'),
        indi = 30;
    indicator.style.marginLeft = indi + 'px';
  
    for(var i = 0; i < btn.length; i++) {
      btn[i].onmousedown = function (e) {
        var newRound = document.createElement('div'),x,y;
     
        newRound.className = 'cercle';
        this.appendChild(newRound);
  
        x = e.pageX - this.offsetLeft;
        y = e.pageY - this.offsetTop;
  
        
        newRound.style.left = x + "px";
        newRound.style.top = y + "px";
        newRound.className += " anim";
  
        indicator.style.marginLeft = indi + (this.dataset.num-1) * 240 + 'px';
  
        setTimeout(function() {
          newRound.remove();
        }, 1200);
      };
    }
  }());

  var waveBtn2 = (function () {
    'use strict';
    var btn2 = document.querySelectorAll('.wave2'),
        tab2 = document.querySelector('.tab-bar2'),
        indicator2 = document.querySelector('.indicator2'),
        indi = 30;
    indicator2.style.marginLeft = indi + 'px';
  
    for(var i = 0; i < btn2.length; i++) {
      btn2[i].onmousedown = function (e) {
        var newRound = document.createElement('div'),x,y;
     
        newRound.className = 'cercle';
        this.appendChild(newRound);
  
        x = e.pageX - this.offsetLeft;
        y = e.pageY - this.offsetTop;
  
        
        newRound.style.left = x + "px";
        newRound.style.top = y + "px";
        newRound.className += " anim";
  
        indicator2.style.marginLeft = indi + (this.dataset.num-1) * 240 + 'px';
  
        setTimeout(function() {
          newRound.remove();
        }, 1200);
      };
    }
  }());


  $(function() {
    var fontSize = 18;
    $("#increase").click(
        function() {
            console.log("click");
            fontSize += 2;
            $("body").css({ 'font-size': fontSize });
            
            $("p").css({ 'font-size': fontSize });
            $("div").css({ 'font-size': fontSize });
        }
    );
    $("#decrease").click(
        function() {
            console.log("click");
            fontSize -= 2;
            $("body").css({ 'font-size': fontSize });
            $("p").css({ 'font-size': fontSize });
            $("div").css({ 'font-size': fontSize });
        }
    );
    $("#default").click(
        function() {
            console.log("click");
            fontSize = 18;
            $("body").css({ 'font-size': fontSize });
            $("p").css({ 'font-size': fontSize });
            $("div").css({ 'font-size': fontSize });
        }
    );
    })
