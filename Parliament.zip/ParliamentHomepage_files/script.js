/*-----------------------------------------------------------------------------------

 	Script - All Custom frontend jQuery scripts & functions
 
-----------------------------------------------------------------------------------*/
(function(){
'use strict';
	
/*---------------------------------------------- 
	SCROLL TO ANCHOR LINK
------------------------------------------------*/
$('a[href^="#"]').on('click', function () {
	var target = $(this.hash);
	if( target.length ) {
		event.preventDefault();
		$('html, body').stop().animate({
			scrollTop: target.offset().top
		}, 500);
	}
});

/* do animations if element is visible
------------------------------------------------*/
function animateOnScroll() {
	if (jQuery("[class*='do-anim']").length > 0) {
		jQuery("[class*='do-anim']").not('.animated')
		.filter(function(i, d) {
			return  jQuery(d).visible(true);
		}).each(function(i) {
			var thisItem = jQuery(this);
			var delayMulti = 200;
			if (thisItem.hasClass("do-anim-modern")) { delayMulti = 10; }
			var delay = i*delayMulti + 100;  // + 150 is to add a small delay
			thisItem.delay(delay).queue(function(){thisItem.addClass('animated');});
		});
	}			
}
	
/* get current scroll position
------------------------------------------------*/
function getCurrentScroll() {
	return window.pageYOffset || document.documentElement.scrollTop;
}
	
/* pin anchor navigation bar
------------------------------------------------*/	
function pinNavAnchor() {
	var scroll = getCurrentScroll();
	var heroHeight = $('#hero').outerHeight();
	if ( scroll >= heroHeight) {
		$('#nav-anchor').addClass('pinned');
	} else {
		$('#nav-anchor').removeClass('pinned');
	}
}
	
/*---------------------------------------------- 
	ANCHOR LINK NAVIGATION BAR
------------------------------------------------*/
$('#nav-anchor a[href^="#"]').on('click', function () {
	$('a').each(function () {
		$(this).removeClass('active');
	});
	$(this).addClass('active');
	var target = $(this.hash);
	var headerHeight = $('#header').outerHeight();
	var anchorHeight = $('#nav-anchor').outerHeight();
	if( target.length ) {
		event.preventDefault();
		var windowWidth = $( window ).width();
		if(windowWidth >= 992) {
			$('html, body').stop().animate({
				scrollTop: target.offset().top - (anchorHeight - 1)
			}, 500);
		} else {
			$('html, body').stop().animate({
				scrollTop: target.offset().top - (headerHeight + anchorHeight - 1)
			}, 500);
		}
	}
});
	
$('.menu-anchor-sidebar a[href^="#"]').on('click', function () {
	$('a').each(function () {
		$(this).removeClass('active');
	});
	$(this).addClass('active');
	var target = $(this.hash);
	var headerHeight = $('#header').outerHeight();
	var anchorHeight = $('#nav-anchor').outerHeight();
	if( target.length ) {
		event.preventDefault();
		var windowWidth = $( window ).width();
		if(windowWidth >= 992) {
			$('html, body').stop().animate({
				scrollTop: target.offset().top - (anchorHeight - 1)
			}, 500);
		} else {
			$('html, body').stop().animate({
				scrollTop: target.offset().top - (headerHeight + anchorHeight - 1)
			}, 500);
		}

	}
});

/* do active menu
------------------------------------------------*/
function activeMenuOnScroll() {
	
	var scrollPosition = $(document).scrollTop();
	
	$('#nav-anchor a[href^="#"]').each(function () {
		var currentLink = $(this);
		var windowWidth = $( window ).width();
		var headerHeight = $('header').outerHeight();
		var anchorHeight = $('#nav-anchor').outerHeight();
		if(windowWidth >= 992) {
			var secTop = $(currentLink.attr("href")).offset().top - anchorHeight -1,
			secBottom = secTop + $(currentLink.attr("href")).outerHeight();
		} else {
			var secTop = $(currentLink.attr("href")).offset().top - anchorHeight - headerHeight -1,
			secBottom = secTop + $(currentLink.attr("href")).outerHeight();
		}
		if (scrollPosition >= secTop && scrollPosition <= secBottom) {
			$('#nav-anchor a').removeClass("active");
			$(this).addClass('active');
			$('#nav-anchor a').find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
		} else {
			$(this).removeClass('active');
		}
	});
	
	$('.menu-anchor-sidebar a[href^="#"]').each(function () {
		var currentLink = $(this);
		var windowWidth = $( window ).width();
		var headerHeight = $('header').outerHeight();
		var anchorHeight = $('#nav-anchor').outerHeight();
		if(windowWidth >= 992) {
			var secTop = $(currentLink.attr("href")).offset().top - anchorHeight -1,
			secBottom = secTop + $(currentLink.attr("href")).outerHeight();
		} else {
			var secTop = $(currentLink.attr("href")).offset().top - anchorHeight - headerHeight -1,
			secBottom = secTop + $(currentLink.attr("href")).outerHeight();
		}
		if (scrollPosition >= secTop && scrollPosition <= secBottom) {
			$('.menu-anchor-sidebar a').removeClass("active");
			$(this).addClass('active');
			$('.menu-anchor-sidebar a').find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
		} else {
			$(this).removeClass('active');
		}
	});

}	


/* header Features ()
------------------------------------------------*/
function headerFeatures() {
	
}


/* misc features which need to be regenerated on resize
------------------------------------------------*/
function resizeAdapt() {
	
	/*---------------------------------------------- 
		Sticky
	------------------------------------------------*/	
	if ($('.sticky-outer').length) {
		var stickySidebar = new StickySidebar('.sticky-outer', {
			topSpacing: 80,
			bottomSpacing: 50,
			containerSelector: '.sticky-wrapper',
			innerWrapperSelector: '.sticky-inner',
			minWidth: 992
		});
	}
	
}

/* isotope load more function
------------------------------------------------*/
function isotopeLoadMore(grid,el,url,datas) {
	
	el.parent(".load-isotope").addClass('loading');
	
	if (url === '#' || !url) { url = srvars.ajaxurl }
	var addData = ''; if (datas) { addData = { action:'sr_load_more', o:datas }; }
	jQuery.ajax({
			type:'POST',			// this might lead to issues for html template
			url:url,
			data: addData,
			dataType:"html",
			error: function () {
				el.parent(".load-isotope").addClass("disabled");	
			},
			success: function(response) { 
				//console.log(response);
				if (response) {
					
					// if hero-side and sticky
					if (jQuery("#hero.sticky_bottom[class*='side-']").length) {
						var position = jQuery("#hero").position();
						var parentHeight = jQuery("#hero").parent().outerHeight();
						var scroll = jQuery(document).scrollTop();
						var addOffset = jQuery(window).height() - (parentHeight - scroll);
						jQuery("#hero").css({"bottom":"auto", "top":position.top+addOffset+"px"});
					}
					
					setTimeout(function(){ 
						var items = jQuery( jQuery(response).find('#'+grid.attr('id')).html());
						items.imagesLoaded(function(){
							grid.append( items ).isotope( 'appended', items);
							//reorganizeIsotope();
							animateOnScroll(false);
							// init video bg for appended items
							if(jQuery().phatVideoBg) { grid.find('.videobg-section').phatVideoBg(); }
						});
						setTimeout(function(){ el.parent(".load-isotope").removeClass('loading'); }, 1000);
					},500);
				} else {
					el.parent(".load-isotope").addClass("disabled");	
				}
			}
	});
	
}
	
	
/* reorganize isotope for ratio
------------------------------------------------*/
function reorganizeIsotope() { 
	jQuery('.isotope-grid[data-ratio]').each(function(){
		var $container = jQuery(this);
		var width = $container.find(".isotope-item:not(.double-width)").width();
		var ratio = $container.data('ratio').split(':');
		ratio = ratio[1] / ratio[0];
		if (!ratio) { ratio = 0.8; }
		var spacing = 0; 
		if ($container.hasClass("isotope-spaced") || $container.hasClass("isotope-spaced-big")) { 
			spacing = parseInt($container.find(".isotope-item").css('marginRight'),10); 
		}
		var height = parseInt(width * ratio, 10);
		if (!$container.find('.isotope-item img:not(.hover)').parent(".ratio-wrapper").length) {
			$container.find('.isotope-item img:not(.hover)').wrap('<div class="ratio-wrapper"></div>');
		}
		$container.find('.isotope-item .ratio-wrapper').css({ 'height': height+'px' });
		if (jQuery(window).width() > 1024) { $container.find('.isotope-item.double-height .ratio-wrapper').css({ 'height': height*2+spacing+'px' }); }
		$container.isotope( 'layout' );
		
	});
}
	
/*---------------------------------------------- 
			S M O O T H   S H O W    (pageloader)
------------------------------------------------*/
jQuery("body").addClass("loaded");
setTimeout(function(){
	setTimeout(function(){ animateOnScroll(true); },500);
	headerFeatures();
}, 500);
setTimeout(function(){
	jQuery("body").addClass("loading-end");	
}, 1000);
	
function toggleMenu() {
	closeSearch();
	$('#header').toggleClass('menu-is-open'); 
	return false;
}
$('.menu-toggle').on('click', toggleMenu);

function closeMenu() {
	$('#header').removeClass('menu-is-open'); 
	return false;
}
$('.pseudo-close').on('click', closeMenu);

function toggleSearch() {
	closeMenu();
	if ( $('.searchsite-container').hasClass('searchsite-is-open') ) {
		$('.searchsite-container').removeClass('searchsite-is-open');
	} else {
		$('.searchsite-container').addClass('searchsite-is-open');
		$('.searchsite-input').focus();
	}
	return false;
}
$('.searchsite-toggle').on('click', toggleSearch);

function closeSearch() {
	$('.searchsite-container').removeClass('searchsite-is-open');
	$('.searchsite-input').val("");
	$('.searchsite-input').blur();
	return false;
}
$('#searchsite-close').on('click', closeSearch);
	
$(window).on('keyup', function(event) {
	if ( $('#header').hasClass('menu-is-open') ) {
		if ( event.keyCode === 27 ) {
			closeMenu();
		}
	}
	if ( $('.searchsite-container').hasClass('searchsite-is-open') ) {
		if ( event.keyCode === 27 ) {
			closeSearch();
		}
	}
	return false;
});
	
/*---------------------------------------------- 
	on Document Ready
------------------------------------------------*/
jQuery( document ).ready(function() {
	
	if( $('#hero').hasClass('text-light') ) { $('#logo-move').addClass('logo-light'); } else { $('#logo-move').removeClass('logo-light'); }
	
});


jQuery(window).on("load",function() {	
	
	
	/*---------------------------------------------- 
				 	L A Z Y   L O A D 
	------------------------------------------------*/
	if(jQuery().unveil && jQuery("img.lazy").length > 0) { 
		jQuery("img.lazy").unveil(800);
	}
	
	
	/*---------------------------------------------- 
			I S O T O P E  /  M A S O N R Y 
	------------------------------------------------*/
	if( jQuery().isotope ) { 
	
		/* Call Isotope  
		------------------------------------------------*/	
		jQuery('.isotope-grid').each(function(){
			var $container = jQuery(this);
			var layout = "masonry";
			if ($container.hasClass("fitrows")) { layout = "fitRows"; }
			$container.imagesLoaded( function(){
				$container.isotope({
					layoutMode: layout,
					itemSelector : '.isotope-item',
					masonry: { columnWidth: '.isotope-item:not(.double-width)' }
				});	
			});
			setTimeout(function() { $container.isotope( 'layout' ); reorganizeIsotope(); }, 500);	
		});
		
		jQuery('.grid-inner').each(function(){
			var $container = jQuery(this);
			var layout = "masonry";
			if ($container.hasClass("fitrows")) { layout = "fitRows"; }
			$container.imagesLoaded( function(){
				$container.isotope({
					layoutMode: layout,
					itemSelector : '.grid-item',
					masonry: { columnWidth: '.grid-sizer' }
				});	
			});
			setTimeout(function() { $container.isotope( 'layout' ); reorganizeIsotope(); }, 500);	
		});
		
					
		
		/* Filter isotope
		------------------------------------------------*/
		jQuery('.grid-filter').on("click", "li a", function() { 
			var thisItem = jQuery(this);
			var parentul = thisItem.parents('ul.grid-filter').data('related-grid');
			if (!parentul) {
				alert('Please specify the dala-related-grid');
			} else {
				thisItem.parents('ul.grid-filter').find('li').removeClass('active');
				thisItem.parent('li').addClass('active');
				var selector = thisItem.attr('data-filter');
				jQuery('#'+parentul).isotope({ filter: selector });
				jQuery('#'+parentul+' .isotope-item .item-inner').not(selector).removeClass("animated");				
				setTimeout(function() { jQuery('#'+parentul+' .isotope-item'+selector+' .item-inner').addClass("animated"); },200);
				
				// adding slug hashtag to url
				var slug = thisItem.data('slug');
				if (slug) { 
					window.location.hash = slug; } 
				else {
					history.pushState("", document.title, window.location.pathname + window.location.search);
				}
			}
			return false;
		});
		
	}
	
	/*---------------------------------------------- 
		O W L   S L I D E R & C A R O U S E L
	------------------------------------------------*/
	if(jQuery().owlCarousel) {
		
		$(".carousel-hero").owlCarousel({
			loop:true,
			items:1,
			margin:0,
			nav:true,
			dots:false,
			autoplay:true,
			autoplayTimeout:15000,
			smartSpeed: 500,
			autoplayHoverPause:true,
			autoHeight:true,
			navText: [
			  '<i class="fas fa-angle-left"></i>',
			  '<i class="fas fa-angle-right"></i>'
			],
		});
		
		$(".carousel-features").owlCarousel({
			loop:true,
			items:1,
			margin:0,
			nav:true,
			dots:false,
			autoplay:true,
			autoplayTimeout:15000,
			smartSpeed: 500,
			autoplayHoverPause:true,
			autoHeight:true,
			navText: [
			  '<i class="fas fa-angle-left"></i>',
			  '<i class="fas fa-angle-right"></i>'
			],
			lazyLoad:true,
			responsive:{
				576:{
					items:2,
					margin:1,
				},
				1200:{
					items:3,
					margin:1,
				},
			},
		});
		
		$(".carousel-academic").owlCarousel({
			loop:true,
			autoHeight:true,
			margin:1,
			nav:true,
			dots:false,
			autoplayTimeout:10000,
			autoplayHoverPause:true,
			responsiveClass:true,
			responsive:{
				0:{
					items:1,
					autoplay:false,
				},
				576:{
					items:2,
					autoplay:false,
				},
				992:{
					items:3,
					autoplay:true,
				},
				1440:{
					items:4,
					autoplay:true,
				},
			},
			navText: [
			  '<i class="fas fa-long-arrow-alt-left"></i>',
			  '<i class="fas fa-long-arrow-alt-right"></i>'
			],
			lazyLoad:true,
			onInitialized: function(me){
				$(me.target).find(".owl-item.active [data-src]:not(.loaded)").each(function(i,v){
					$(v).addClass("loaded").css("background-image", "url("+$(v).attr("data-src")+")");
				});
			},
			onTranslated: function(me){
				$(me.target).find(".owl-item.active [data-src]:not(.loaded)").each(function(i,v){
					$(v).addClass("loaded").css("background-image", "url("+$(v).attr("data-src")+")");
				});
			}
		});
		
		$(".carousel-impact").owlCarousel({
			loop:true,
			autoHeight:true,
			margin:1,
			nav:true,
			dots:false,
			autoplayTimeout:10000,
			autoplayHoverPause:true,
			responsiveClass:true,
			responsive:{
				0:{
					items:1,
					autoplay:false,
				},
				576:{
					items:2,
					autoplay:false,
					margin:15,
				},
				992:{
					items:3,
					autoplay:true,
					margin:15,
				},
				1440:{
					items:4,
					autoplay:true,
					margin:30,
				},
			},
			navText: [
			  '<i class="fas fa-long-arrow-alt-left"></i>',
			  '<i class="fas fa-long-arrow-alt-right"></i>'
			],
			lazyLoad:true,
			onInitialized: function(me){
				$(me.target).find(".owl-item.active [data-src]:not(.loaded)").each(function(i,v){
					$(v).addClass("loaded").css("background-image", "url("+$(v).attr("data-src")+")");
				});
			},
			onTranslated: function(me){
				$(me.target).find(".owl-item.active [data-src]:not(.loaded)").each(function(i,v){
					$(v).addClass("loaded").css("background-image", "url("+$(v).attr("data-src")+")");
				});
			}
		});
		
		$(".carousel-banner").owlCarousel({
			loop:true,
			items:1,
			margin:0,
			nav:true,
			dots:false,
			autoplay: true,
			autoplayTimeout: 15000,
			smartSpeed: 750,
			autoplayHoverPause: true,
			autoHeight: true,
			navText: [
			  '<i class="fas fa-angle-left"></i>',
			  '<i class="fas fa-angle-right"></i>'
			],
			responsive:{
				576:{
					items:2,
					margin:1
				},
				992:{
					items:3,
					margin:1,
				},
			},
			lazyLoad:true,
		});
		
		jQuery(".owl-slider").owlCarousel({
			items:1,
			nav: false,
			navText:false,
			dots: true,
			smartSpeed : 600,			
			singleItem : true,
			autoHeight : true,
			loop: false,
			autoplay: false,
			autoplayHoverPause : true,
			navRewind: false
		});
		
		
		jQuery('.faculty-slider').owlCarousel({
			items: 1,
			loop: true,
			autoHeight: true,
			margin: 0,
			nav: true,
			autoplay: false,
			autoplayTimeout: 7500,
			smartSpeed: 500,
			autoplayHoverPause: true,
			lazyLoad: true,
			navText: [
			  '<i class="fas fa-long-arrow-alt-left"></i>',
			  '<i class="fas fa-long-arrow-alt-right"></i>'
			],
			responsive:{
				768: { items: 2, margin: 1, autoplay: false },
				992: { items: 2, margin: 1, autoplay: true },
			  	1200: { items: 3, margin: 1, autoplay: true },
				1920: { items: 4, margin: 1, autoplay: true },
			}
		});
				
	}
	
	/*==============================================================
		Dropdown category menu
	==============================================================*/
	function DropDown(el) {
		this.dd = el;
		this.initEvents();
	}
	DropDown.prototype = {
		initEvents : function() {
			var obj = this;
			obj.dd.on('click', function(event){
				jQuery(this).toggleClass('active');
				event.stopPropagation();
			});	
		}
	};
	jQuery(function() {
		var dd = new DropDown( jQuery('#dd') );
		jQuery(document).click(function() {
			jQuery('.wrapper-dropdown').removeClass('active');
		});
	});
	/*---------------------------------------------- 
			T O G G L E  &  A C C O R D I O N
	------------------------------------------------*/		
	jQuery(".toggle-item").each(function() {
		if (!jQuery(this).find('.toggle-active').length) { jQuery(this).find('.toggle-inner').slideUp(300); }
		jQuery(this).find('.toggle-active').parent(".toggle-item").siblings('.toggle-item').find('.toggle-inner').slideUp(300);	
		jQuery(this).find('.toggle-active').siblings('.toggle-inner').slideDown(300);							
	});
	
	jQuery(".toggle-item").on("click", ".toggle-title", function() { 
		var thisItem = jQuery(this); 
		var parentdiv = thisItem.parent('div').parent('div');
		var active = thisItem.parent('div').find('.toggle-inner').css('display');
		
		if (jQuery(parentdiv).attr('class') === 'accordion') {
			if (active !== 'none' ) { 
				jQuery(parentdiv).find('.toggle-item .toggle-inner').slideUp(300);
				thisItem.toggleClass('toggle-active');
			} else {
				jQuery(parentdiv).find('.toggle-item .toggle-inner').slideUp(300);
				jQuery(parentdiv).find('.toggle-item .toggle-title').removeClass('toggle-active');
				
				thisItem.toggleClass('toggle-active');
				thisItem.siblings('.toggle-inner').slideDown(300);
			}
		} else {
			thisItem.toggleClass('toggle-active');
			thisItem.siblings('.toggle-inner').slideToggle(300);
		}
		
		return false;
	});
	
	
	/*------------------------------------------------------- 
		S C R O L L   T O (back to top, scroll down)
	---------------------------------------------------------*/
	jQuery('body').on('click', '.totop,#scrolldown', function() {
		var topPos = 0;
		if (jQuery(this).attr("id") === "scrolldown") { topPos = jQuery("#page-body").offset().top; }
		jQuery('html,body').animate({ scrollTop: topPos}, 1000, 'easeInOutQuart');
		return false;
	});
	
	/*------------------------------------------------------- 
		L A N G U A G E - C L I C K (responsive)
	---------------------------------------------------------*/
	jQuery('body').on('click', '.language-icon', function() {
		jQuery('header').toggleClass("language-active");
		return false;
	});
	
	/*==============================================================
		lightbox gallery
	 ==============================================================*/
	$('.lightbox-gallery').magnificPopup({
		delegate: 'a',
		type: 'image',
		tLoading: 'Loading image #%curr%...',
		mainClass: 'mfp-fade',
		fixedContentPos: true,
		closeBtnInside: true,
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
		}
	});

	/*==============================================================
		single image lightbox - zoom animation
	==============================================================*/
	$('.single-image-lightbox').magnificPopup({
		type: 'image',
		closeOnContentClick: true,
		fixedContentPos: true,
		closeBtnInside: true,
		mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
		image: {
			verticalFit: true,
		},
		zoom: {
			enabled: true,
			duration: 300 // don't foget to change the duration also in CSS
		}
	});

	$('.image-popup-vertical-fit').magnificPopup({
		type: 'image',
		closeOnContentClick: true,
		mainClass: 'mfp-img-mobile',
		image: {
		  verticalFit: true
		}
	});

	/*==============================================================
		video magnific popup
	==============================================================*/
	$('.popup-embed, .popup-youtube, .popup-vimeo, .popup-googlemap').magnificPopup({
		disableOn: 300,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: true
	});
	
	resizeAdapt();
	
	/*
	$('a[href^="#"]').on('click', function () {

		//var target = $(this.getAttribute('href'));
		var target = $(this.hash);
		if( target.length ) {
			event.preventDefault();
			$('html, body').stop().animate({
				scrollTop: target.offset().top
			}, 500);
		}
	});
	
	$('nav.cf a[href^="#"]').on('click', function () {
		$('a').each(function () {
			$(this).removeClass('active');
		});
		$(this).addClass('active');
		//var target = $(this.getAttribute('href'));
		var target = $(this.hash);
		if( target.length ) {
			event.preventDefault();
			var windowWidth = $( window ).width();
			if(windowWidth >= 992) {
				$('html, body').stop().animate({
					scrollTop: target.offset().top - 79
				}, 500);
			} else {
				console.log(target.offset().top);
				$('html, body').stop().animate({
					scrollTop: target.offset().top - 89
				}, 500);
			}
			
		}
	});
	
	$(function() {
		var menu = $('nav.cf ul.cf');
		$('#openup').on('click', function(e) {
			e.preventDefault(); menu.slideToggle();
		});
		$(window).resize(function(){
			var w = $(this).width(); 
			if(w >= 992 && menu.is(':hidden')) {
			  menu.removeAttr('style');
			}
		});
		$('nav li').on('click', function() {                
			var w = $(window).width(); 
			if(w < 992 ) {
				menu.slideToggle(); 
			}
		});
	  	$('.open-menu').height($(window).height());
	});
	*/
	
	
	/*
	$('.menu-item-has-children').children('a').on('click', function(event){
		event.preventDefault();
		$(this).toggleClass('submenu-open').next('.sub-menu').slideToggle(400, "easeInOutCubic").end().parent('.menu-item-has-children').siblings('.menu-item-has-children').children('a').removeClass('submenu-open').next('.sub-menu').slideUp(400, "easeInOutCubic");
	});
	*/
	$('.menu-item-has-children').children('a').on('click', function(event){
		event.preventDefault();
		$(this).toggleClass('submenu-open').next('.sub-menu').slideToggle(400, "easeInOutCubic").parent('.menu-item-has-children').toggleClass('menu-item-has-children-open').end().parent('.menu-item-has-children').siblings('.menu-item-has-children').children('a').removeClass('submenu-open').next('.sub-menu').slideUp(400, "easeInOutCubic").parent('.menu-item-has-children').removeClass('menu-item-has-children-open');
	});

	$('.list-toggle li').children('.list-toggle-title').on('click', function(event){
		event.preventDefault();
		$(this).parent('.list-toggle li').toggleClass('active').end().parent('.list-toggle li').siblings('.list-toggle li').children('.list-toggle-title').parent('.list-toggle li').removeClass('active');
	});


	
	
	
	
	
	
});

jQuery(window).on('scroll',function() { 
	animateOnScroll(false);
	headerFeatures(); 
	//onScroll();
	pinNavAnchor();
	activeMenuOnScroll();
	
	/*
	var scroll = getCurrentScroll();
	var heroHeight = $('#hero').outerHeight() - 1;
	if ( scroll >= heroHeight) {
		$('nav.cf').addClass('cf-pinned');
	} else {
		$('nav.cf').removeClass('cf-pinned');
	}
	
	function onScroll(){
		var scrollPosition = $(document).scrollTop();
		
		$('nav.cf.anchor ul.cf a').each(function () {
			var currentLink = $(this);
			var windowWidth = $( window ).width();
			var headerHeight = $('header').outerHeight();
			var nav_height = $('nav.cf').outerHeight();
			if(windowWidth >= 992) {
				var secTop = $(currentLink.attr("href")).offset().top - nav_height,
        		secBottom = secTop + $(currentLink.attr("href")).outerHeight();
			} else {
				var secTop = $(currentLink.attr("href")).offset().top - nav_height - headerHeight,
        		secBottom = secTop + $(currentLink.attr("href")).outerHeight();
			}
			if (scrollPosition >= secTop && scrollPosition <= secBottom) {
				$('nav.cf ul.cf a').removeClass("active");
				$(this).addClass('active');
      			$('nav.cf ul.cf a').find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
				
			} else {
				$(this).removeClass('active');
			}
		});
		
		$('.sidebar-menu a').each(function () {
			var currentLink = $(this);
			var secTop = $(currentLink.attr("href")).offset().top - 1,
        		secBottom = secTop + $(currentLink.attr("href")).outerHeight();
			if (scrollPosition >= secTop && scrollPosition <= secBottom) {
				$('.sidebar-menu a').removeClass("active");
				$(this).addClass('active');
      			$('.sidebar-menu a').find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
				
			} else{
				$(this).removeClass('active');
			}
		});
		
	}
	
	
	function getCurrentScroll() {
		return window.pageYOffset || document.documentElement.scrollTop;
	}
	*/
	
});

jQuery(window).on('resize',function() { 
	
	reorganizeIsotope();
	resizeAdapt(); 
	
	equalheight('.equalheight');
	
});
	
	
$(window).on('load', function () {
	$(window).resize(function() {
		
		var windowHeight = $(window).height();
		var windowWidth = $(window).width();
		var headerHeight = $('header').outerHeight();
		var resizeTimer = null;
		var viewPortBgMode = null;
		var viewPortImgMode = null;
		
		equalheight('.equalheight');
		
		if (windowWidth < 992) {
			$(".hero-full").height(windowHeight - headerHeight);
			$(".hero-full .carousel-hero").height(windowHeight - headerHeight);
			$(".hero-full .hero-banner").height(windowHeight - headerHeight);
			//$(".hero-full .owl-height").height(windowHeight - headerHeight);
			
			//$(".hero-full .hero-media").height(windowHeight - headerHeight);
			//$(".hero-full .hero-entry").height(windowHeight - headerHeight);
		} else {
			$(".hero-full").height(windowHeight);
			$(".hero-full .carousel-hero").height(windowHeight);
			$(".hero-full .hero-banner").height(windowHeight);
			//$(".hero-full .owl-height").height(windowHeight);
			//$(".hero-full .hero-media").height(windowHeight);
			//$(".hero-full .hero-entry").height(windowHeight);
		}
		
		
		
		/*==============================================================
				Responsive image
		==============================================================*/
		var changeBgMode = function() {
			var checkedViewPort = null;
			var $adaptiveBg = $('[data-bg-mobile]');
			if ( windowWidth > 991 ) {
				checkedViewPort = 'desktop';
			} else {
				checkedViewPort = 'mobile';
			}
			if( viewPortBgMode !== checkedViewPort ) {
				$adaptiveBg.each(function() {
					var attr = $(this).attr('data-bg-'+ checkedViewPort);
					if(typeof attr !== typeof undefined && attr !== false) {
						$(this).css( 'background-image', 'url(' + attr + ')');
					} else { 
						$(this).css( 'background-image', 'url(' + $(this).attr('data-bg-mobile') + ')');
					}
				});
				viewPortBgMode = checkedViewPort;
			}
		};
		
		var changeImageMode = function(){
			var checkedViewPort = null;
			var $adaptiveImg = $('[data-img-mobile]');
			if ( windowWidth > 991 ) {
				checkedViewPort = 'desktop';
			} else {
				checkedViewPort = 'mobile';
			}
			if( viewPortImgMode !== checkedViewPort ){
				$adaptiveImg.each(function(){
					var attr = $(this).attr('data-img-'+ checkedViewPort);
					if(typeof attr !== typeof undefined && attr !== false) {
						$(this).attr('src', attr);
					} else { 
						$(this).attr('src', $(this).attr('data-img-mobile') );
					}
				});
				viewPortImgMode = checkedViewPort;
			}
		};
		
		
		/*==============================================================
				Parallax
		==============================================================*/
		var changeParallaxMode = function() {
			if (windowWidth > 991 && !Modernizr.touchevents) {
				
				// Enllax Plugin
				//$(window).enllax();
				
				//var rellax = new Rellax('.rellax');

				// Paralax Background
				var moveBg = function(el,i) {
					var wHeight = $(window).height();
					var elTop = $(el).offset().top;
					var elHeight = $(el).innerHeight();
					if(elTop > wHeight) {
						var elReachBottom = elTop - wHeight;
					} else {
						var elReachBottom = 0;
					}
					var elReachTop = elTop + elHeight;
					$(window).scroll(function() {
						var wScroll = $(this).scrollTop();
						var moveDistance = ( wScroll - elReachBottom )/i;
						if (( wScroll > elReachBottom ) && ( wScroll < elReachTop )) {
							$(el).css({"background-position-y":moveDistance, "background-attachment":"fixed"});
						}
					});
				};
				var initParalaxBg = function() {
					$(".paralaxbg").each(function() {
						var x = $(this).attr("data-paralaxbg-speed");
						if(x) {
							moveBg(this,x);
						} else {
							moveBg(this,20);
						}	
					});
				};
				initParalaxBg();
				
			}
		};
		
		$(function(){
			changeBgMode();
			changeImageMode();
			changeParallaxMode();
			
			$(window).on('resize',function(){
				clearTimeout( resizeTimer );
				resizeTimer = null;
				resizeTimer = setTimeout(function(){
					changeBgMode();
					changeImageMode();
					changeParallaxMode();
				},100);
			});
		});
		
		
	}).resize();
});
	

})(jQuery);